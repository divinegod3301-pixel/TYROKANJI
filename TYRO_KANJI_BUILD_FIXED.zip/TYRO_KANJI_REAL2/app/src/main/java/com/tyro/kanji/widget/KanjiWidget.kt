package com.tyro.kanji.widget

import android.content.Context
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.action.ActionParameters
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.tyro.kanji.data.KanjiCatalog

class KanjiWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        provideContent {
            val prefs = context.getSharedPreferences("widget", Context.MODE_PRIVATE)
            val index = prefs.getInt("index", 0).mod(KanjiCatalog.items.size)
            val k = KanjiCatalog.items[index]
            val dark = (context.resources.configuration.uiMode and 0x30) == 0x20
            val bg = ColorProvider(if (dark) Color.Black else Color.White)
            val fg = ColorProvider(if (dark) Color.White else Color.Black)

            Box(GlanceModifier.fillMaxSize().background(bg).padding(12.dp)) {
                Column(GlanceModifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Row(GlanceModifier.fillMaxWidth()) {
                        Spacer(GlanceModifier.fillMaxWidth())
                        Text(
                            "↻",
                            style = TextStyle(color = fg, fontSize = 20.sp),
                            modifier = GlanceModifier.clickable(onClick = actionRunCallback<RefreshAction>())
                        )
                    }
                    Spacer(GlanceModifier.height(2.dp))
                    Text(k.kanji, style = TextStyle(color = fg, fontSize = 44.sp))
                    Text(k.reading, style = TextStyle(color = fg, fontSize = 16.sp))
                    Text(romanize(k.reading), style = TextStyle(color = fg, fontSize = 14.sp))
                    Text(k.meaning, style = TextStyle(color = fg, fontSize = 14.sp), maxLines = 2)
                }
            }
        }
    }

    private fun romanize(s: String): String {
        val map = mapOf(
            "あ" to "a", "い" to "i", "う" to "u", "え" to "e", "お" to "o",
            "か" to "ka", "き" to "ki", "く" to "ku", "け" to "ke", "こ" to "ko",
            "さ" to "sa", "し" to "shi", "す" to "su", "せ" to "se", "そ" to "so",
            "た" to "ta", "ち" to "chi", "つ" to "tsu", "て" to "te", "と" to "to",
            "な" to "na", "に" to "ni", "ぬ" to "nu", "ね" to "ne", "の" to "no",
            "は" to "ha", "ひ" to "hi", "ふ" to "fu", "へ" to "he", "ほ" to "ho",
            "ま" to "ma", "み" to "mi", "む" to "mu", "め" to "me", "も" to "mo",
            "や" to "ya", "ゆ" to "yu", "よ" to "yo", "ら" to "ra", "り" to "ri",
            "る" to "ru", "れ" to "re", "ろ" to "ro", "わ" to "wa", "を" to "o", "ん" to "n"
        )
        var out = s
        map.keys.sortedByDescending { it.length }.forEach { out = out.replace(it, map[it]!!) }
        return out
    }
}

class RefreshAction : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
        val prefs = context.getSharedPreferences("widget", Context.MODE_PRIVATE)
        val old = prefs.getInt("index", 0)
        prefs.edit().putInt("index", (old + 1) % KanjiCatalog.items.size).apply()
        KanjiWidget().update(context, glanceId)
    }
}

class KanjiWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = KanjiWidget()
}
