# TYRO KANJI

Offline Japanese Kanji learning app and resizable Glance home-screen widget.

## Build
Use Java 17 and Gradle 8.11.1, then run `gradle :app:assembleDebug`.

## Product
Home dashboard, searchable Kanji library, Kanji detail cards, flashcards, quiz mode, SRS review buttons, favorites, statistics, settings, offline Room persistence, and a responsive light/dark widget with a top-right refresh action.

## Data
The supplied Kanji source contains 307 records. No fabricated records are included. JLPT metadata is nullable because the supplied source does not contain authoritative per-record JLPT classifications.

## Dictionary data attribution

Kanji On'yomi/Kun'yomi readings are based on KANJIDIC2 data maintained by the Electronic Dictionary Research and Development Group (EDRDG). Common example words/compounds are based on JMdict Japanese-English dictionary data maintained by EDRDG. Data is included with attribution and under the applicable Creative Commons Attribution-ShareAlike terms.
