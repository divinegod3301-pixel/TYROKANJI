package com.tyro.kanji

import android.app.Application
import androidx.glance.appwidget.updateAll
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tyro.kanji.data.*
import com.tyro.kanji.widget.KanjiWidget
import com.tyro.kanji.widget.WidgetScheduler
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val db = TyroDatabase.get(app)
    private val dao = db.kanjiDao()
    private val prefs = app.getSharedPreferences("tyro_settings", 0)

    val kanji = dao.observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val mastered = dao.mastered().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val due = dao.dueCount(System.currentTimeMillis()).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    private val _query = MutableStateFlow("")
    val query = _query.asStateFlow()
    val filtered = combine(dao.observeAll(), _query) { all, q ->
        if (q.isBlank()) all else all.filter {
            it.kanji.contains(q) || it.hiragana.contains(q) || it.romaji.contains(q) || it.meaning.contains(q, true)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedIds = MutableStateFlow(loadSelectedIds())
    val selectedIds = _selectedIds.asStateFlow()
    private val _shuffle = MutableStateFlow(prefs.getBoolean("shuffle", true))
    val shuffle = _shuffle.asStateFlow()
    private val _refreshToken = MutableStateFlow(0)
    val refreshToken = _refreshToken.asStateFlow()
    private val _theme = MutableStateFlow(prefs.getString("theme", "system") ?: "system")
    val theme = _theme.asStateFlow()

    init { viewModelScope.launch { DatabaseSeeder.seed(db); restoreImportedKanji(); ensureSelection(); WidgetScheduler.schedule(app) } }

    private fun loadSelectedIds(): Set<Int> = prefs.getString("selected_ids", null)
        ?.split(',')?.mapNotNull { it.toIntOrNull() }?.toSet() ?: emptySet()

    private suspend fun ensureSelection() {
        if (_selectedIds.value.isEmpty()) {
            val all = dao.observeAll().first()
            if (all.isNotEmpty()) setSelectedIds(all.map { it.id }.toSet())
        }
    }

    fun importKanji(raw: String): Int {
        val lines = raw.lines().map { it.trim() }.filter { it.isNotBlank() }
        if (lines.isEmpty()) return 0
        val importedIds = mutableListOf<Int>()
        viewModelScope.launch {
            val all = dao.observeAll().first()
            val existingChars = all.map { it.kanji }.toSet()
            var nextId = prefs.getInt("next_custom_id", 10001)
            val newItems = mutableListOf<KanjiEntity>()
            for (line in lines) {
                val hasDetails = line.contains("—") || line.contains("–") || line.contains("|") || line.contains("-")
                if (!hasDetails && line.length > 1) {
                    line.filter { !it.isWhitespace() }.forEach { ch ->
                        val char = ch.toString()
                        if (existingChars.contains(char) || newItems.any { it.kanji == char }) return@forEach
                        val item = KanjiEntity(id = nextId++, kanji = char, hiragana = "—", romaji = "", meaning = "Custom Kanji")
                        newItems += item
                        importedIds += item.id
                    }
                    continue
                }
                val parts = line.split(Regex("\\s*[—–|-]\\s*"), limit = 3).map { it.trim() }
                val char = parts.firstOrNull()?.firstOrNull()?.toString() ?: continue
                if (char.isBlank() || existingChars.contains(char) || newItems.any { it.kanji == char }) continue
                val reading = parts.getOrNull(1).orEmpty().ifBlank { "—" }
                val meaning = parts.getOrNull(2).orEmpty().ifBlank { "Custom Kanji" }
                val item = KanjiEntity(id = nextId++, kanji = char, hiragana = reading, romaji = "", meaning = meaning)
                newItems += item
                importedIds += item.id
            }
            if (newItems.isNotEmpty()) {
                dao.insertAll(newItems)
                prefs.edit().putInt("next_custom_id", nextId).apply()
                val selected = _selectedIds.value.toMutableSet().apply { addAll(importedIds) }
                setSelectedIds(selected)
                updateWidget()
            }
        }
        return lines.size
    }

    private suspend fun restoreImportedKanji() {
        // Imported Kanji are persisted directly in Room. This method intentionally stays
        // lightweight so existing installs keep their original 307 entries untouched.
    }

    fun setQuery(q: String) { _query.value = q }

    fun setSelected(id: Int, selected: Boolean) {
        val next = _selectedIds.value.toMutableSet().apply { if (selected) add(id) else remove(id) }
        setSelectedIds(next)
    }

    fun selectAll() { viewModelScope.launch { setSelectedIds(dao.observeAll().first().map { it.id }.toSet()) } }
    fun clearSelection() { setSelectedIds(emptySet()) }

    private fun setSelectedIds(ids: Set<Int>) {
        _selectedIds.value = ids
        prefs.edit().putString("selected_ids", ids.sorted().joinToString(",")).apply()
        _refreshToken.value++
    }

    fun setShuffle(enabled: Boolean) {
        _shuffle.value = enabled
        prefs.edit().putBoolean("shuffle", enabled).apply()
        _refreshToken.value++
    }

    fun setTheme(value: String) {
        _theme.value = value
        prefs.edit().putString("theme", value).apply()
    }

    fun refreshStudy() { _refreshToken.value++ }

    fun studyOrder(all: List<KanjiEntity>): List<KanjiEntity> {
        val selected = all.filter { it.id in _selectedIds.value }
        return if (_shuffle.value) selected.shuffled(Random(_refreshToken.value + 1000)) else selected
    }

    fun progress(id: Int) = flow { emit(dao.progress(id) ?: ProgressEntity(id)) }

    fun favorite(id: Int, value: Boolean) = viewModelScope.launch {
        dao.saveProgress((dao.progress(id) ?: ProgressEntity(id)).copy(favorite = value))
    }

    fun review(id: Int, rating: Int) = viewModelScope.launch {
        val old = dao.progress(id) ?: ProgressEntity(id)
        val now = System.currentTimeMillis()
        val interval = when (rating) {
            0 -> 1
            1 -> max(1, old.intervalDays * 2)
            2 -> max(1, old.intervalDays * 3)
            else -> max(4, old.intervalDays * 4)
        }
        val mastery = min(5, old.mastery + if (rating >= 2) 1 else 0)
        dao.saveProgress(old.copy(
            intervalDays = interval,
            dueAt = now + interval * 86_400_000L,
            repetitions = old.repetitions + 1,
            correct = old.correct + if (rating >= 2) 1 else 0,
            wrong = old.wrong + if (rating == 0) 1 else 0,
            mastery = mastery,
            lastReviewed = now
        ))
    }

    fun saveWidgetFont(font: String) { prefs.edit().putString("widget_font", font).apply(); updateWidget() }
    fun saveWidgetSize(size: Int) { prefs.edit().putInt("widget_size", size.coerceIn(28, 72)).apply(); updateWidget() }
    fun saveWidgetColor(color: String) { prefs.edit().putString("widget_color", color).apply(); updateWidget() }
    fun saveWidgetAutoRefresh(minutes: Int) {
        prefs.edit().putInt("widget_auto_refresh", minutes).apply()
        WidgetScheduler.schedule(getApplication())
        updateWidget()
    }

    private fun updateWidget() {
        viewModelScope.launch { KanjiWidget().updateAll(getApplication<Application>()) }
    }
}
