package com.tyro.kanji.widget

import android.content.Context
import android.content.res.Configuration
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.action.ActionParameters
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.provideContent
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.padding
import androidx.glance.text.FontFamily
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.tyro.kanji.data.KanjiEntity
import com.tyro.kanji.data.TyroDatabase
import kotlinx.coroutines.flow.first

private fun isDark(context: Context): Boolean =
    (context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

private fun colorFor(name: String, dark: Boolean): Color = when (name) {
    "white" -> Color.White
    "black" -> Color.Black
    "blue" -> Color(0xFF4D8DFF)
    "green" -> Color(0xFF4CAF50)
    "purple" -> Color(0xFF9C6ADE)
    "orange" -> Color(0xFFFF9800)
    "pink" -> Color(0xFFE85D9E)
    "red" -> Color(0xFFE53935)
    "cyan" -> Color(0xFF00ACC1)
    else -> if (dark) Color.White else Color(0xFF222222)
}

private fun fontFor(name: String): FontFamily = when (name) {
    "serif" -> FontFamily.Serif
    "mono" -> FontFamily.Monospace
    "cursive" -> FontFamily.Cursive
    else -> FontFamily.SansSerif
}

internal suspend fun selectedKanji(context: Context): List<KanjiEntity> {
    val all = TyroDatabase.get(context).kanjiDao().observeAll().first()
    val prefs = context.getSharedPreferences("tyro_settings", Context.MODE_PRIVATE)
    val raw = prefs.getString("selected_ids", null)
    if (raw == null) return all.filter { it.id < 10000 }
    val ids = raw.split(',').mapNotNull { it.toIntOrNull() }.toSet()
    return all.filter { it.id in ids }
}

class KanjiWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val choices = selectedKanji(context)
        val safeChoices = if (choices.isEmpty()) TyroDatabase.get(context).kanjiDao().observeAll().first() else choices
        provideContent {
            val prefs = context.getSharedPreferences("tyro_settings", Context.MODE_PRIVATE)
            val current = prefs.getInt("widget_index", 0)
            val index = if (safeChoices.isEmpty()) 0 else current.mod(safeChoices.size)
            val k = safeChoices.getOrNull(index)
            val dark = isDark(context)
            val colorName = prefs.getString("widget_color", "auto") ?: "auto"
            val fg = ColorProvider(colorFor(colorName, dark))
            val font = fontFor(prefs.getString("widget_font", "sans") ?: "sans")
            val size = prefs.getInt("widget_size", 48).coerceIn(28, 96)

            Box(GlanceModifier.fillMaxSize().padding(8.dp)) {
                Column(GlanceModifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(GlanceModifier.fillMaxWidth(), contentAlignment = Alignment.TopEnd) {
                        Text(
                            "↻",
                            style = TextStyle(color = fg, fontSize = 18.sp, fontFamily = font, fontWeight = FontWeight.Bold),
                            modifier = GlanceModifier.clickable(onClick = actionRunCallback<RefreshAction>()).padding(2.dp)
                        )
                    }
                    if (k != null) {
                        Text(k.kanji, style = TextStyle(color = fg, fontSize = size.sp, fontFamily = font, fontWeight = FontWeight.Bold))
                        if (k.hiragana.isNotBlank() && k.hiragana != "—") Text(k.hiragana, style = TextStyle(color = fg, fontSize = 16.sp, fontFamily = font))
                        if (k.romaji.isNotBlank()) Text(k.romaji, style = TextStyle(color = fg, fontSize = 13.sp, fontFamily = font))
                        Text(k.meaning, style = TextStyle(color = fg, fontSize = 13.sp, fontFamily = font), maxLines = 2)
                    }
                }
            }
        }
    }
}

class RefreshAction : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
        val choices = selectedKanji(context)
        val prefs = context.getSharedPreferences("tyro_settings", Context.MODE_PRIVATE)
        val old = prefs.getInt("widget_index", 0)
        val next = if (choices.size <= 1) 0 else ((0 until choices.size).filter { it != old.mod(choices.size) }.random())
        prefs.edit().putInt("widget_index", next).apply()
        KanjiWidget().update(context, glanceId)
    }
}

class KanjiWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = KanjiWidget()
}
