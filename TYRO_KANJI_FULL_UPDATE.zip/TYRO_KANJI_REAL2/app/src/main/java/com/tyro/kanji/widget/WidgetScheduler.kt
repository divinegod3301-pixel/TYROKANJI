package com.tyro.kanji.widget

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.tyro.kanji.widget.KanjiWidget
import androidx.glance.appwidget.updateAll
import kotlinx.coroutines.launch

object WidgetScheduler {
    private const val ACTION = "com.tyro.kanji.widget.AUTO_REFRESH"
    private const val REQUEST = 4027

    fun schedule(context: Context) {
        val app = context.applicationContext
        val prefs = app.getSharedPreferences("tyro_settings", Context.MODE_PRIVATE)
        val minutes = prefs.getInt("widget_auto_refresh", 5)
        val alarm = app.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(app, WidgetAutoRefreshReceiver::class.java).setAction(ACTION)
        val pending = PendingIntent.getBroadcast(
            app,
            REQUEST,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarm.cancel(pending)
        if (minutes <= 0) return
        val interval = minutes * 60_000L
        alarm.setInexactRepeating(
            AlarmManager.RTC_WAKEUP,
            System.currentTimeMillis() + interval,
            interval,
            pending
        )
    }
}

class WidgetAutoRefreshReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != "com.tyro.kanji.widget.AUTO_REFRESH") return
        val prefs = context.getSharedPreferences("tyro_settings", Context.MODE_PRIVATE)
        val minutes = prefs.getInt("widget_auto_refresh", 5)
        if (minutes <= 0) return
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Default).launch {
            val choices = selectedKanji(context.applicationContext)
            val current = prefs.getInt("widget_index", 0)
            val next = if (choices.size <= 1) 0 else (current + 1) % choices.size
            prefs.edit().putInt("widget_index", next).apply()
            KanjiWidget().updateAll(context.applicationContext)
        }
    }
}

class WidgetBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED || intent?.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            WidgetScheduler.schedule(context.applicationContext)
        }
    }
}
