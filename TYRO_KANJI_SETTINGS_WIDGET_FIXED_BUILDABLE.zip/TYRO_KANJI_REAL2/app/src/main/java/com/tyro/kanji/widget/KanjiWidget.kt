package com.tyro.kanji.widget

import android.content.Context
import android.content.res.Configuration
import androidx.glance.text.FontFamily
import androidx.glance.text.FontWeight
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.action.ActionParameters
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.provideContent
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.tyro.kanji.data.KanjiCatalog

private fun isDark(context: Context): Boolean =
    (context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

private fun colorFor(name: String, dark: Boolean): Color {
    return when (name) {
        "blue" -> Color(0xFF4D8DFF)
        "green" -> Color(0xFF4CAF50)
        "purple" -> Color(0xFF9C6ADE)
        "orange" -> Color(0xFFFF9800)
        "pink" -> Color(0xFFE85D9E)
        else -> if (dark) Color.White else Color(0xFF222222)
    }
}

private fun fontFor(name: String): FontFamily = when (name) {
    "serif" -> FontFamily.Serif
    "mono" -> FontFamily.Monospace
    "cursive" -> FontFamily.Cursive
    else -> FontFamily.SansSerif
}

private fun selectedIndices(context: Context): List<Int> {
    val prefs = context.getSharedPreferences("tyro_settings", Context.MODE_PRIVATE)
    val ids = prefs.getString("selected_ids", null)?.split(',')?.mapNotNull { it.toIntOrNull() }?.toSet()
    if (ids.isNullOrEmpty()) return KanjiCatalog.items.indices.toList()
    return KanjiCatalog.items.indices.filter { it + 1 in ids }
}

class KanjiWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        provideContent {
            val prefs = context.getSharedPreferences("tyro_settings", Context.MODE_PRIVATE)
            val choices = selectedIndices(context)
            val current = prefs.getInt("widget_index", 0)
            val index = choices.getOrElse(current.mod(choices.size)) { 0 }
            val k = KanjiCatalog.items[index]
            val dark = isDark(context)
            val colorName = prefs.getString("widget_color", "auto") ?: "auto"
            val fg = ColorProvider(colorFor(colorName, dark))
            val font = fontFor(prefs.getString("widget_font", "sans") ?: "sans")
            val size = prefs.getInt("widget_size", 48).coerceIn(28, 72)

            // Intentionally no background: the widget stays transparent.
            Box(GlanceModifier.fillMaxSize().padding(10.dp)) {
                Column(GlanceModifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Row(GlanceModifier.fillMaxWidth()) {
                        Spacer(GlanceModifier.fillMaxWidth())
                        Text(
                            "↻",
                            style = TextStyle(color = fg, fontSize = 20.sp, fontFamily = font, fontWeight = FontWeight.Bold),
                            modifier = GlanceModifier.clickable(onClick = actionRunCallback<RefreshAction>())
                        )
                    }
                    Spacer(GlanceModifier.height(0.dp))
                    Text(k.kanji, style = TextStyle(color = fg, fontSize = size.sp, fontFamily = font, fontWeight = FontWeight.Bold))
                    Text(k.reading, style = TextStyle(color = fg, fontSize = 16.sp, fontFamily = font))
                    Text(romanize(k.reading), style = TextStyle(color = fg, fontSize = 13.sp, fontFamily = font))
                    Text(k.meaning, style = TextStyle(color = fg, fontSize = 13.sp, fontFamily = font), maxLines = 2)
                }
            }
        }
    }

    private fun romanize(s: String): String {
        val map = mapOf(
            "あ" to "a", "い" to "i", "う" to "u", "え" to "e", "お" to "o", "か" to "ka", "き" to "ki", "く" to "ku", "け" to "ke", "こ" to "ko",
            "さ" to "sa", "し" to "shi", "す" to "su", "せ" to "se", "そ" to "so", "た" to "ta", "ち" to "chi", "つ" to "tsu", "て" to "te", "と" to "to",
            "な" to "na", "に" to "ni", "ぬ" to "nu", "ね" to "ne", "の" to "no", "は" to "ha", "ひ" to "hi", "ふ" to "fu", "へ" to "he", "ほ" to "ho",
            "ま" to "ma", "み" to "mi", "む" to "mu", "め" to "me", "も" to "mo", "や" to "ya", "ゆ" to "yu", "よ" to "yo", "ら" to "ra", "り" to "ri",
            "る" to "ru", "れ" to "re", "ろ" to "ro", "わ" to "wa", "を" to "o", "ん" to "n"
        )
        var out = s
        map.keys.sortedByDescending { it.length }.forEach { out = out.replace(it, map[it]!!) }
        return out
    }
}

class RefreshAction : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
        val choices = selectedIndices(context)
        val prefs = context.getSharedPreferences("tyro_settings", Context.MODE_PRIVATE)
        val old = prefs.getInt("widget_index", 0)
        val next = if (choices.size <= 1) 0 else ((0 until choices.size).filter { it != old.mod(choices.size) }.random())
        prefs.edit().putInt("widget_index", next).apply()
        KanjiWidget().update(context, glanceId)
    }
}

class KanjiWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = KanjiWidget()
}
