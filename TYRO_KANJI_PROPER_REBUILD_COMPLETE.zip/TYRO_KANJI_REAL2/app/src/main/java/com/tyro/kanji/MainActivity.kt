package com.tyro.kanji

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.*
import com.tyro.kanji.data.KanjiEntity

class MainActivity:ComponentActivity(){
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{TyroKanjiApp()}}
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun TyroKanjiApp(vm:MainViewModel=viewModel()){
 val nav=rememberNavController(); var tab by remember{mutableStateOf(0)}
 MaterialTheme(colorScheme=if(isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()){
  Scaffold(bottomBar={
   NavigationBar{
    listOf("Home","Learn","Study","Stats","Settings").forEachIndexed{ i,label->
     val icon=listOf(Icons.Default.Home,Icons.Default.MenuBook,Icons.Default.School,Icons.Default.Insights,Icons.Default.Settings)[i]
     NavigationBarItem(selected=tab==i,onClick={tab=i;nav.navigate(label.lowercase()){launchSingleTop=true}},icon={Icon(icon,null)},label={Text(label)})
    }
   }
  }){pad->
   NavHost(nav,startDestination="home",modifier=Modifier.padding(pad)){
    composable("home"){Home(vm)}
    composable("learn"){Learn(vm){nav.navigate("detail/$it")}}
    composable("study"){Study(vm)}
    composable("stats"){Stats(vm)}
    composable("settings"){Settings()}
    composable("detail/{id}"){e-> val id=e.arguments?.getString("id")?.toIntOrNull(); val k=vm.kanji.collectAsState().value.firstOrNull{it.id==id}; if(k!=null) Detail(k,vm){nav.popBackStack()} }
   }
  }
 }
}

@Composable fun Page(title:String,content:@Composable ColumnScope.()->Unit){
 Column(Modifier.fillMaxSize().padding(horizontal=20.dp),content=content)
}

@Composable fun Home(vm:MainViewModel){
 val list by vm.kanji.collectAsState(); val mastered by vm.mastered.collectAsState(); val due by vm.due.collectAsState()
 Page("Home"){
  Spacer(Modifier.height(18.dp)); Text("TYRO KANJI",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.ExtraBold)
  Text("Your daily Japanese practice",color=MaterialTheme.colorScheme.onSurfaceVariant)
  Spacer(Modifier.height(18.dp))
  Card(shape=RoundedCornerShape(28.dp),colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.primaryContainer),modifier=Modifier.fillMaxWidth()){
   Column(Modifier.padding(22.dp)){Text("Today's Kanji",style=MaterialTheme.typography.labelLarge); Spacer(Modifier.height(8.dp))
    val k=list.firstOrNull(); Text(k?.kanji ?: "人",style=MaterialTheme.typography.displayLarge,fontWeight=FontWeight.Bold)
    Text(k?.meaning ?: "person",style=MaterialTheme.typography.titleMedium)
    Spacer(Modifier.height(14.dp)); LinearProgressIndicator(progress={if(list.isEmpty())0f else mastered.toFloat()/list.size},Modifier.fillMaxWidth())
    Text("$mastered mastered  •  $due reviews due",Modifier.padding(top=8.dp))
   }
  }
  Spacer(Modifier.height(16.dp))
  Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(12.dp)){StatCard("Kanji",list.size.toString(),Modifier.weight(1f));StatCard("Mastered",mastered.toString(),Modifier.weight(1f));StatCard("Due",due.toString(),Modifier.weight(1f))}
  Spacer(Modifier.height(18.dp)); Text("Continue learning",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)
  Spacer(Modifier.height(8.dp)); Text("Use Learn to choose your kanji, then Study to review with flashcards and SRS.",color=MaterialTheme.colorScheme.onSurfaceVariant)
 }
}
@Composable fun StatCard(a:String,b:String,m:Modifier){Card(m,shape=RoundedCornerShape(20.dp)){Column(Modifier.padding(14.dp)){Text(b,style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Text(a,color=MaterialTheme.colorScheme.onSurfaceVariant)}}}

@Composable fun Learn(vm:MainViewModel,onOpen:(Int)->Unit){
 val list by vm.filtered.collectAsState(); val q by vm.query.collectAsState()
 Page("Learn"){
  Spacer(Modifier.height(18.dp)); OutlinedTextField(q,vm::setQuery,Modifier.fillMaxWidth(),singleLine=true,placeholder={Text("Search Kanji, meaning, reading…")},leadingIcon={Icon(Icons.Default.Search,null)})
  Spacer(Modifier.height(12.dp)); Text("${list.size} Kanji",fontWeight=FontWeight.SemiBold)
  LazyColumn(contentPadding=PaddingValues(vertical=8.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
   items(list,key={it.id}){k->KanjiRow(k){onOpen(k.id)}}
  }
 }
}
@Composable fun KanjiRow(k:KanjiEntity,onClick:()->Unit){Card(Modifier.fillMaxWidth().clickable{onClick()},shape=RoundedCornerShape(18.dp)){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Text(k.kanji,style=MaterialTheme.typography.displaySmall,fontWeight=FontWeight.Bold,Modifier.width(70.dp));Column{Text(k.hiragana,fontWeight=FontWeight.SemiBold);Text(k.romaji,color=MaterialTheme.colorScheme.onSurfaceVariant);Text(k.meaning,maxLines=1)}}}}

@Composable fun Detail(k:KanjiEntity,vm:MainViewModel,back:()->Unit){
 var flipped by remember{mutableStateOf(false)}; val p by vm.progress(k.id).collectAsState(initial=ProgressEntity(k.id))
 Page("Kanji details"){
  Spacer(Modifier.height(12.dp)); Row(verticalAlignment=Alignment.CenterVertically){IconButton(back){Icon(Icons.Default.ArrowBack,null)};Text("Kanji details",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)}
  Card(Modifier.fillMaxWidth().clickable{flipped=!flipped},shape=RoundedCornerShape(30.dp)){Column(Modifier.padding(28.dp),horizontalAlignment=Alignment.CenterHorizontally){Text(k.kanji,style=MaterialTheme.typography.displayLarge,fontWeight=FontWeight.Bold);Text(k.hiragana,style=MaterialTheme.typography.titleLarge);Text(k.romaji,color=MaterialTheme.colorScheme.onSurfaceVariant);Spacer(Modifier.height(12.dp));Text(if(flipped)"${k.meaning}\n\nTap to hide" else "Tap card to reveal meaning",style=MaterialTheme.typography.titleLarge)}}}
  Spacer(Modifier.height(14.dp));Text(k.meaning,style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Spacer(Modifier.height(8.dp));Text("Mastery ${p.mastery}/5")
  Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){FilterChip(p.favorite, {vm.favorite(k.id,!p.favorite)}, label={Text(if(p.favorite)"Saved" else "Favorite")},leadingIcon={Icon(Icons.Default.Favorite,null)})}
  Spacer(Modifier.height(18.dp));Text("SRS review",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold);Spacer(Modifier.height(8.dp))
  Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){listOf("Again" to 0,"Hard" to 1,"Good" to 2,"Easy" to 3).forEach{(t,r)->Button({vm.review(k.id,r)},Modifier.weight(1f)){Text(t)}}}
 }
}

@Composable fun Study(vm:MainViewModel){
 val list by vm.kanji.collectAsState(); var index by remember{mutableIntStateOf(0)}; var mode by remember{mutableStateOf(0)}; var reveal by remember{mutableStateOf(false)}
 val k=list.getOrNull(index.coerceAtMost((list.size-1).coerceAtLeast(0)))
 Page("Study"){
  Spacer(Modifier.height(18.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){FilterChip(mode==0,{mode=0},label={Text("Flashcards")});FilterChip(mode==1,{mode=1},label={Text("Quiz")})}
  Spacer(Modifier.height(20.dp))
  if(k==null) Text("Loading your offline Kanji…") else if(mode==0){
   Card(Modifier.fillMaxWidth().height(390.dp).clickable{reveal=!reveal},shape=RoundedCornerShape(32.dp)){Column(Modifier.fillMaxSize().padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Text(k.kanji,style=MaterialTheme.typography.displayLarge,fontWeight=FontWeight.Bold);if(reveal){Text(k.meaning,style=MaterialTheme.typography.headlineSmall);Text(k.hiragana);Text(k.romaji,color=MaterialTheme.colorScheme.onSurfaceVariant)}else Text("Tap to flip",color=MaterialTheme.colorScheme.onSurfaceVariant)}}}
  else QuizCard(k){answer->if(answer)vm.review(k.id,2) else vm.review(k.id,0);index=(index+1)%list.size}
  Spacer(Modifier.height(14.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){OutlinedButton({index=(index-1+list.size)%list.size;reveal=false},Modifier.weight(1f)){Text("Previous")};Button({index=(index+1)%list.size;reveal=false},Modifier.weight(1f)){Text("Next")}}
 }
}
@Composable fun QuizCard(k:KanjiEntity,onAnswer:(Boolean)->Unit){
 var selected by remember(k.id){mutableStateOf<String?>(null)}; val opts=listOf(k.meaning,"water","school","mountain").shuffled()
 Card(Modifier.fillMaxWidth().padding(top=10.dp),shape=RoundedCornerShape(28.dp)){Column(Modifier.padding(22.dp)){Text("What does this mean?",style=MaterialTheme.typography.titleMedium);Text(k.kanji,style=MaterialTheme.typography.displayLarge,fontWeight=FontWeight.Bold);opts.forEach{o->Button({selected=o;onAnswer(o==k.meaning)},Modifier.fillMaxWidth().padding(top=8.dp)){Text(o)}}}}
}
@Composable fun Stats(vm:MainViewModel){val total by vm.kanji.collectAsState();val mastered by vm.mastered.collectAsState();Page("Statistics"){Spacer(Modifier.height(18.dp));Text("Your progress",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold);Spacer(Modifier.height(16.dp));StatCard("Learned / mastered","$mastered / ${total.size}",Modifier.fillMaxWidth());Spacer(Modifier.height(12.dp));Text("Accuracy and review history are stored offline in Room and updated by SRS reviews.",color=MaterialTheme.colorScheme.onSurfaceVariant)}}
@Composable fun Settings(){Page("Settings"){Spacer(Modifier.height(18.dp));Text("Settings",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold);Spacer(Modifier.height(12.dp));listOf("Learning content","JLPT level","Flashcards","Quiz","Widget appearance","Theme","Statistics","Notifications","Backup","FAQ").forEach{Card(Modifier.fillMaxWidth().padding(vertical=4.dp),shape=RoundedCornerShape(18.dp)){ListItem(headlineContent={Text(it)},trailingContent={Icon(Icons.Default.ChevronRight,null)})}}}
