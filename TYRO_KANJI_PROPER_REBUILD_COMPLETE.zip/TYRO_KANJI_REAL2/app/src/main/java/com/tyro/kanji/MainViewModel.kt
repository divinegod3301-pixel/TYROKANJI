package com.tyro.kanji

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tyro.kanji.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.min

class MainViewModel(app:Application):AndroidViewModel(app) {
    private val db=TyroDatabase.get(app)
    private val dao=db.kanjiDao()
    val kanji=dao.observeAll().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
    val mastered=dao.mastered().stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),0)
    val due=dao.dueCount(System.currentTimeMillis()).stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),0)
    private val _query=MutableStateFlow("")
    val query=_query.asStateFlow()
    val filtered=_query.flatMapLatest { if(it.isBlank()) dao.observeAll() else dao.search(it) }
        .stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())

    init { viewModelScope.launch { DatabaseSeeder.seed(db) } }
    fun setQuery(q:String){_query.value=q}
    fun progress(id:Int)=flow {
        emit(dao.progress(id) ?: ProgressEntity(id))
    }
    fun favorite(id:Int, value:Boolean)=viewModelScope.launch {
        dao.saveProgress((dao.progress(id) ?: ProgressEntity(id)).copy(favorite=value))
    }
    fun review(id:Int, rating:Int)=viewModelScope.launch {
        val old=dao.progress(id) ?: ProgressEntity(id)
        val now=System.currentTimeMillis()
        val interval=when(rating){0->1;1->max(1,old.intervalDays*2);2->max(1,old.intervalDays*3);else->max(4,old.intervalDays*4)}
        val mastery=min(5,old.mastery + if(rating>=2) 1 else 0)
        dao.saveProgress(old.copy(intervalDays=interval,dueAt=now+interval*86_400_000L,repetitions=old.repetitions+1,correct=old.correct+if(rating>=2)1 else 0,wrong=old.wrong+if(rating==0)1 else 0,mastery=mastery,lastReviewed=now))
    }
}
