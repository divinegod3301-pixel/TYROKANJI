# TYRO KANJI

Offline Japanese Kanji learning app and resizable Glance home-screen widget.

## Build
Use Java 17 and Gradle 8.11.1, then run `gradle :app:assembleDebug`.

## Product
Home dashboard, searchable Kanji library, Kanji detail cards, flashcards, quiz mode, SRS review buttons, favorites, statistics, settings, offline Room persistence, and a responsive light/dark widget with a top-right refresh action.

## Data
The supplied Kanji source contains 307 records. No fabricated records are included. JLPT metadata is nullable because the supplied source does not contain authoritative per-record JLPT classifications.
