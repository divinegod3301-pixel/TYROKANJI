package com.kanjiwidget

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.*
import com.kanjiwidget.data.*
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { TyroKanjiApp() } }
}

@Composable
fun TyroKanjiApp() {
    val nav = rememberNavController()
    MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
        Scaffold(bottomBar = { NavigationBar {
            listOf("home" to "Home", "learn" to "Learn", "flash" to "Cards", "quiz" to "Quiz", "stats" to "Stats").forEach { (route,label) ->
                NavigationBarItem(selected = nav.currentBackStackEntryAsState().value?.destination?.route == route, onClick = { nav.navigate(route) { launchSingleTop = true } }, icon = { Text(when(route){"home"->"⌂";"learn"->"漢";"flash"->"▣";"quiz"->"✓";else->"◔"}) }, label={Text(label)})
            }
        }}) { pad ->
            NavHost(nav, startDestination="home", Modifier.padding(pad)) {
                composable("home") { HomeScreen(nav) }; composable("learn") { LearnScreen(nav) }; composable("flash") { FlashcardScreen() }; composable("quiz") { QuizScreen() }; composable("stats") { StatsScreen() }
                composable("detail/{id}") { e -> KanjiDetailScreen(e.arguments?.getString("id")?.toIntOrNull() ?: 1, nav) }
                composable("settings") { SettingsScreen() }
            }
        }
    }
}

@Composable fun HomeScreen(nav: NavHostController) {
    val due = remember { mutableStateOf(0) }
    val learned = remember { mutableStateOf(0) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding=PaddingValues(18.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
        item { Text("TYRO KANJI", style=MaterialTheme.typography.headlineLarge, fontWeight=FontWeight.Bold); Text("Japanese Kanji learning • offline") }
        item { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp)) { Text("Today's Kanji", style=MaterialTheme.typography.titleMedium); Text(KanjiRepository.items.first().character, fontSize=72.sp, modifier=Modifier.align(Alignment.CenterHorizontally)); Text(KanjiRepository.items.first().meaning, modifier=Modifier.align(Alignment.CenterHorizontally)); Button(onClick={nav.navigate("detail/1")}, modifier=Modifier.fillMaxWidth()){Text("Study")}} } }
        item { Row(horizontalArrangement=Arrangement.spacedBy(10.dp), modifier=Modifier.fillMaxWidth()) { StatCard("Streak","0 days",Modifier.weight(1f)); StatCard("Due","${due.value}",Modifier.weight(1f)); StatCard("Learned","${learned.value}",Modifier.weight(1f)) } }
        item { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp)) { Text("Daily Goal",fontWeight=FontWeight.Bold); LinearProgressIndicator(progress={0f},Modifier.fillMaxWidth().padding(vertical=10.dp)); Text("0 / 10 Kanji") } } }
        item { OutlinedButton(onClick={nav.navigate("settings")},Modifier.fillMaxWidth()){Text("Settings")}; Spacer(Modifier.height(40.dp)) }
    }
}
@Composable fun StatCard(title:String,value:String,modifier:Modifier){Card(modifier){Column(Modifier.padding(12.dp)){Text(title,style=MaterialTheme.typography.labelMedium);Text(value,fontWeight=FontWeight.Bold)}}}

@Composable fun LearnScreen(nav:NavHostController){
    var query by remember { mutableStateOf("") }; var filter by remember { mutableStateOf("All") }
    val list=KanjiRepository.items.filter { (query.isBlank() || it.character.contains(query)||it.meaning.contains(query)||it.hiragana.contains(query)||it.romaji.contains(query)) && (filter=="All" || it.jlpt==filter) }
    Column(Modifier.fillMaxSize().padding(16.dp)){ Text("Kanji Library",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold); Spacer(Modifier.height(10.dp)); OutlinedTextField(query,{query=it},Modifier.fillMaxWidth(),label={Text("Search Kanji, meaning, kana, romaji")}); Spacer(Modifier.height(8.dp)); Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){ listOf("All","N5","N4").forEach{FilterChip(selected=filter==it,onClick={filter=it},label={Text(it)})} }
        LazyColumn(contentPadding=PaddingValues(vertical=12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){items(list){k->Card(onClick={nav.navigate("detail/${k.number}")},Modifier.fillMaxWidth()){Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Text(k.character,fontSize=42.sp);Spacer(Modifier.width(14.dp));Column{Text(k.meaning,fontWeight=FontWeight.Bold);Text("${k.hiragana} • ${k.romaji}");Text(k.jlpt,style=MaterialTheme.typography.labelSmall)}}}}}
    }
}

@Composable fun FlashcardScreen(){ var index by remember{mutableStateOf(0)}; var flipped by remember{mutableStateOf(false)}; val k=KanjiRepository.items[index]; Column(Modifier.fillMaxSize().padding(20.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){ Text("Flash Cards",style=MaterialTheme.typography.headlineMedium); Spacer(Modifier.height(18.dp)); Card(onClick={flipped=!flipped},Modifier.fillMaxWidth().height(330.dp)){Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){if(!flipped) Text(k.character,fontSize=110.sp) else Column(horizontalAlignment=Alignment.CenterHorizontally){Text(k.meaning,fontSize=30.sp,fontWeight=FontWeight.Bold);Text(k.hiragana);Text(k.romaji);if(k.example.isNotBlank())Text(k.example,Modifier.padding(20.dp))}}}; Spacer(Modifier.height(18.dp)); Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick={index=(index+KanjiRepository.items.size-1)%KanjiRepository.items.size;flipped=false}){Text("Again")};Button(onClick={index=(index+1)%KanjiRepository.items.size;flipped=false}){Text("Good")};Button(onClick={index=(index+2)%KanjiRepository.items.size;flipped=false}){Text("Easy")}};Text("Tap the card to flip",Modifier.padding(12.dp))}}

@Composable fun QuizScreen(){ var index by remember{mutableStateOf(0)}; var score by remember{mutableStateOf(0)}; var feedback by remember{mutableStateOf("")}; val k=KanjiRepository.items[index]; val choices=listOf(k.meaning)+KanjiRepository.items.shuffled().take(3).map{it.meaning}.distinct().take(3); Column(Modifier.fillMaxSize().padding(20.dp),horizontalAlignment=Alignment.CenterHorizontally){Text("Quiz",style=MaterialTheme.typography.headlineMedium);Text("Kanji → Meaning",style=MaterialTheme.typography.titleMedium);Spacer(Modifier.height(30.dp));Text(k.character,fontSize=100.sp);choices.forEach{c->Button(onClick={if(c==k.meaning){score++;feedback="Correct";index=(index+1)%KanjiRepository.items.size}else feedback="Try again"}},Modifier.fillMaxWidth().padding(vertical=4.dp)){Text(c)}};Text("Score: $score",Modifier.padding(10.dp));Text(feedback)}}

@Composable fun StatsScreen(){LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){item{Text("Statistics",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)};item{StatCard("Accuracy","0%",Modifier.fillMaxWidth())};item{StatCard("Study time","0 min",Modifier.fillMaxWidth())};item{StatCard("Current streak","0 days",Modifier.fillMaxWidth())};item{StatCard("Longest streak","0 days",Modifier.fillMaxWidth())};item{StatCard("Learned Kanji","0 / ${KanjiRepository.items.size}",Modifier.fillMaxWidth())};item{StatCard("XP / Level","0 XP • Level 1",Modifier.fillMaxWidth())}}}

@Composable fun KanjiDetailScreen(id:Int,nav:NavHostController){val k=KanjiRepository.items.getOrNull(id-1)?:KanjiRepository.items.first();LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(24.dp),horizontalAlignment=Alignment.CenterHorizontally){item{TextButton({nav.popBackStack()}){Text("← Back")};Text(k.character,fontSize=120.sp);Text(k.meaning,fontSize=28.sp,fontWeight=FontWeight.Bold);Text("${k.hiragana} • ${k.romaji}",fontSize=20.sp);Spacer(Modifier.height(16.dp));Text("JLPT ${k.jlpt}");Text("Stroke count: ${if(k.strokeCount==0) "—" else k.strokeCount}");Text("Onyomi: ${k.onyomi.ifBlank{"—"}}");Text("Kunyomi: ${k.kunyomi.ifBlank{"—"}}");Spacer(Modifier.height(20.dp));if(k.example.isNotBlank())Text("Example: ${k.example}");if(k.exampleMeaning.isNotBlank())Text(k.exampleMeaning);Spacer(Modifier.height(24.dp));Button({}){Text("Hear")};OutlinedButton({}){Text("Favorite")};OutlinedButton({}){Text("Share")}}}}

@Composable fun SettingsScreen(){LazyColumn(Modifier.fillMaxSize(),contentPadding=PaddingValues(18.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){item{Text("Settings",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)};listOf("Word Cycle","Learning Content","JLPT Level","Flash Cards","Quiz","Widget Appearance","Theme","Statistics","Notifications","Backup","FAQ").forEach{item{Card(Modifier.fillMaxWidth()){Row(Modifier.padding(18.dp),verticalAlignment=Alignment.CenterVertically){Text(it,Modifier.weight(1f));Text("›",fontSize=24.sp)}}}}}}
