package com.kanjiwidget.widget

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.action.ActionParameters
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.provideContent
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.padding
import androidx.glance.layout.width
import androidx.glance.material3.GlanceTheme
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.kanjiwidget.data.KanjiRepository
import kotlin.random.Random

class RefreshKanjiAction : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
        context.getSharedPreferences("widget", Context.MODE_PRIVATE).edit()
            .putInt("index", Random.nextInt(KanjiRepository.items.size)).apply()
        KanjiAppWidget().update(context, glanceId)
    }
}

class KanjiAppWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        provideContent { GlanceTheme { WidgetContent(context) } }
    }
}

@Composable
private fun WidgetContent(context: Context) {
    val prefs = context.getSharedPreferences("widget", Context.MODE_PRIVATE)
    val index = prefs.getInt("index", 0).coerceIn(0, KanjiRepository.items.lastIndex)
    val item = KanjiRepository.items[index]
    val textColor = GlanceTheme.colors.onSurface

    Box(GlanceModifier.fillMaxSize().padding(8.dp)) {
        Row(GlanceModifier.fillMaxWidth(), horizontalAlignment = Alignment.End) {
            Text(
                "↻",
                style = TextStyle(fontSize = 20.sp, color = textColor),
                modifier = GlanceModifier.clickable(onClick = actionRunCallback<RefreshKanjiAction>()).padding(4.dp)
            )
        }
        Column(
            GlanceModifier.fillMaxSize().padding(top = 18.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(item.character, style = TextStyle(fontSize = 42.sp, color = textColor))
            Text(item.hiragana, style = TextStyle(fontSize = 15.sp, color = textColor))
            Text(item.romaji, style = TextStyle(fontSize = 13.sp, color = textColor))
            Text(item.meaning, style = TextStyle(fontSize = 14.sp, color = textColor))
        }
    }
}
