package com.kanjiwidget.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ProgressDao {
    @Query("SELECT * FROM kanji_progress WHERE kanjiNumber = :id LIMIT 1")
    suspend fun get(id: Int): ProgressEntity?

    @Query("SELECT * FROM kanji_progress")
    fun observeAll(): Flow<List<ProgressEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: ProgressEntity)

    @Query("SELECT * FROM kanji_progress WHERE dueAt <= :now ORDER BY dueAt")
    fun due(now: Long): Flow<List<ProgressEntity>>
}
