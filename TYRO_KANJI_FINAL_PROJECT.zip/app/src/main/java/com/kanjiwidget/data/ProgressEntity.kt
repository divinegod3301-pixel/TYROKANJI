package com.kanjiwidget.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "kanji_progress")
data class ProgressEntity(
    @PrimaryKey val kanjiNumber: Int,
    val repetitions: Int = 0,
    val intervalDays: Int = 0,
    val ease: Double = 2.5,
    val dueAt: Long = 0L,
    val correct: Int = 0,
    val attempts: Int = 0,
    val favorite: Boolean = false,
    val lastReviewedAt: Long = 0L
)
