package com.kanjiwidget.data

object SrsEngine {
    enum class Rating { AGAIN, HARD, GOOD, EASY }
    fun schedule(old: ProgressEntity, rating: Rating, now: Long = System.currentTimeMillis()): ProgressEntity {
        val days = when (rating) {
            Rating.AGAIN -> 0
            Rating.HARD -> maxOf(1, (old.intervalDays * 1.2).toInt())
            Rating.GOOD -> when (old.intervalDays) { 0 -> 1; 1 -> 3; else -> maxOf(4, (old.intervalDays * old.ease).toInt()) }
            Rating.EASY -> when (old.intervalDays) { 0 -> 4; else -> maxOf(4, (old.intervalDays * old.ease * 1.3).toInt()) }
        }
        val easeDelta = when (rating) { Rating.AGAIN -> -0.2; Rating.HARD -> -0.15; Rating.GOOD -> 0.0; Rating.EASY -> 0.15 }
        return old.copy(repetitions = if (rating == Rating.AGAIN) 0 else old.repetitions + 1, intervalDays = days, ease = (old.ease + easeDelta).coerceIn(1.3, 3.0), dueAt = now + days * 86_400_000L, correct = old.correct + if (rating == Rating.AGAIN) 0 else 1, attempts = old.attempts + 1, lastReviewedAt = now)
    }
}
