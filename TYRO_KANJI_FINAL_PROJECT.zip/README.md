# TYRO KANJI

Offline Japanese Kanji learning app and resizable home-screen widget.

## Widget
- Minimal transparent-style layout
- Follows device light/dark theme through Glance Material 3 theme colors
- Resizable horizontally and vertically
- Refresh icon in the top-right corner
- Refresh changes the displayed Kanji without opening the app
- No JLPT label on the widget

## App
- Home dashboard
- Kanji library/search
- Flashcards
- Quiz mode
- Statistics
- Kanji details
- Room-backed SRS progress model
- Offline-first architecture
- Navigation Compose
- WorkManager dependency for future scheduled reminders/background jobs

## Data note
The supplied source dataset currently contains 307 Kanji records. The project intentionally does not invent 13 additional records. The data file should be replaced/extended with the user's authoritative 320-Kanji master list before claiming the dataset is complete.
