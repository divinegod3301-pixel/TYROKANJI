# Data status

The source dataset included with the supplied project contains 307 Kanji records. This build does not fabricate the missing 13 records. The application architecture is ready for the complete 320-record master dataset to be inserted.
