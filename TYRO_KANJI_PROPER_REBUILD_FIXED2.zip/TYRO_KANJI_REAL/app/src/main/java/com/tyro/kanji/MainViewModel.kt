package com.tyro.kanji

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tyro.kanji.data.KanjiRepository
import com.tyro.kanji.data.TyroDatabase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.emptyFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = KanjiRepository(TyroDatabase.get(app).kanjiDao())

    val kanji = repo.all
    val mastered = repo.mastered
    val due = repo.due()
    val query = MutableStateFlow("")
    val results: StateFlow<List<com.tyro.kanji.data.KanjiEntity>> = query
        .flatMapLatest { if (it.isBlank()) repo.all else repo.search(it) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    init {
        viewModelScope.launch { repo.seed() }
    }

    fun setQuery(q: String) { query.value = q }
    fun review(id: Int, rating: Int) = viewModelScope.launch { repo.review(id, rating) }
    fun favorite(id: Int) = viewModelScope.launch { repo.toggleFavorite(id) }
}
