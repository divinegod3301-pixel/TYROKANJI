package com.tyro.kanji.widget

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.GlanceTheme
import androidx.glance.background
import androidx.glance.action.ActionParameters
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.provideContent
import androidx.glance.appwidget.cornerRadius
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.dp
import androidx.glance.unit.sp
import kotlin.random.Random

object WidgetState {
    var index: Int = 0
}

class RefreshCallback : ActionCallback {
    override suspend fun onAction(context: Context, glanceId: GlanceId, parameters: ActionParameters) {
        WidgetState.index = Random.nextInt(KanjiWidgetData.items.size)
        KanjiWidget().update(context, glanceId)
    }
}

class KanjiWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        provideContent { WidgetUi() }
    }
}

@Composable
private fun WidgetUi() {
    val k = KanjiWidgetData.items[WidgetState.index % KanjiWidgetData.items.size]
    val textColor = GlanceTheme.colors.onSurface
    Box(
        GlanceModifier
            .fillMaxSize()
            .cornerRadius(24.dp)
            .background(GlanceTheme.colors.widgetBackground)
            .padding(14.dp)
    ) {
        Column(
            GlanceModifier.fillMaxSize(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                GlanceModifier.fillMaxWidth(),
                horizontalAlignment = Alignment.End
            ) {
                Text(
                    text = "↻",
                    modifier = GlanceModifier.clickable(actionRunCallback<RefreshCallback>()),
                    style = TextStyle(fontSize = 18.sp, color = textColor)
                )
            }
            Spacer(GlanceModifier.height(2.dp))
            Text(k.kanji, style = TextStyle(fontSize = 38.sp, fontWeight = FontWeight.Bold, color = textColor))
            Text(k.hiragana, style = TextStyle(fontSize = 17.sp, color = textColor))
            Text(k.romaji, style = TextStyle(fontSize = 13.sp, color = textColor))
            Text(k.meaning, style = TextStyle(fontSize = 14.sp, color = textColor), maxLines = 2)
        }
    }
}

object KanjiWidgetData {
    data class W(val kanji: String, val hiragana: String, val romaji: String, val meaning: String)
    val items = listOf(
        W("人", "ひと", "hito", "person"), W("日", "ひ", "hi", "day / sun"),
        W("一", "いち", "ichi", "one"), W("二", "に", "ni", "two"),
        W("三", "さん", "san", "three"), W("顔", "かお", "kao", "face"),
        W("声", "こえ", "koe", "voice"), W("森", "もり", "mori", "forest")
    )
}

class KanjiWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = KanjiWidget()
}
