package com.tyro.kanji

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.tyro.kanji.data.KanjiEntity

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TyroApp() }
    }
}

@Composable
fun TyroApp(vm: MainViewModel = viewModel()) {
    val nav = rememberNavController()
    val colors = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()
    MaterialTheme(colorScheme = colors) {
        NavHost(navController = nav, startDestination = "home") {
            composable("home") { Home(vm, { nav.navigate("learn") }, { nav.navigate("quiz") }) }
            composable("learn") { Learn(vm) { nav.navigate("detail/$it") } }
            composable("detail/{id}") { entry ->
                val id = entry.arguments?.getString("id")?.toIntOrNull()
                val item by vm.kanji.collectAsState(emptyList())
                item.firstOrNull { it.id == id }?.let { k ->
                    Detail(k, vm) { nav.popBackStack() }
                }
            }
            composable("quiz") { Quiz(vm) { nav.popBackStack() } }
        }
    }
}

@Composable
private fun Shell(title: String, content: @Composable ColumnScope.() -> Unit) {
    Scaffold(topBar = { TopAppBar(title = { Text(title, fontWeight = FontWeight.Bold) }) }) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            content = content
        )
    }
}

@Composable
private fun Home(vm: MainViewModel, learn: () -> Unit, quiz: () -> Unit) {
    val mastered by vm.mastered.collectAsState(0)
    val due by vm.due.collectAsState(0)
    val total = 307
    Shell("TYRO KANJI") {
        Text("Your daily Japanese practice", style = MaterialTheme.typography.titleMedium)
        Card(shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp)) {
                Text("Today's Kanji", style = MaterialTheme.typography.labelLarge)
                Text("一", style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold)
                Text("いち • ichi • one")
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
            Stat("Mastered", mastered.toString(), Modifier.weight(1f))
            Stat("Reviews", due.toString(), Modifier.weight(1f))
        }
        Button(onClick = learn, modifier = Modifier.fillMaxWidth()) { Text("Learn Kanji") }
        OutlinedButton(onClick = quiz, modifier = Modifier.fillMaxWidth()) { Text("Start Quiz") }
        Text("Progress", style = MaterialTheme.typography.titleLarge)
        LinearProgressIndicator(
            progress = { (mastered / total.toFloat()).coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth()
        )
        Text("$mastered / $total learned")
    }
}

@Composable
private fun Stat(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.padding(16.dp)) {
            Text(label)
            Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun Learn(vm: MainViewModel, open: (Int) -> Unit) {
    val items by vm.results.collectAsState(emptyList())
    val query by vm.query.collectAsState()
    Shell("Kanji Library") {
        OutlinedTextField(
            value = query,
            onValueChange = vm::setQuery,
            label = { Text("Search kanji, meaning, hiragana or romaji") },
            modifier = Modifier.fillMaxWidth()
        )
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(items, key = { it.id }) { k ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { open(k.id) },
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(k.kanji, style = MaterialTheme.typography.displaySmall, modifier = Modifier.width(70.dp))
                        Column {
                            Text(k.meaning, fontWeight = FontWeight.Bold)
                            Text("${k.hiragana} • ${k.romaji}")
                            Text(k.jlpt, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Detail(k: KanjiEntity, vm: MainViewModel, back: () -> Unit) {
    Shell("Kanji Details") {
        Text(k.kanji, style = MaterialTheme.typography.displayLarge, fontWeight = FontWeight.Bold)
        Text(k.hiragana, style = MaterialTheme.typography.headlineMedium)
        Text(k.romaji, style = MaterialTheme.typography.titleLarge)
        Text(k.meaning, style = MaterialTheme.typography.headlineSmall)
        AssistChip(onClick = {}, label = { Text(k.jlpt) })
        Spacer(Modifier.height(8.dp))
        Text("Example sentence", style = MaterialTheme.typography.titleMedium)
        Text(if (k.example.isBlank()) "No example sentence yet" else k.example)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { vm.review(k.id, 0) }) { Text("Again") }
            Button(onClick = { vm.review(k.id, 2) }) { Text("Good") }
            OutlinedButton(onClick = { vm.favorite(k.id) }) { Text("Favorite") }
        }
        OutlinedButton(onClick = back, modifier = Modifier.fillMaxWidth()) { Text("Back") }
    }
}

@Composable
private fun Quiz(vm: MainViewModel, back: () -> Unit) {
    var index by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(0) }
    val list by vm.kanji.collectAsState(emptyList())
    val k = list.getOrNull(if (list.isEmpty()) 0 else index % list.size)
    Shell("Quiz") {
        if (k != null) {
            Text("What does this mean?", style = MaterialTheme.typography.titleLarge)
            Text(k.kanji, style = MaterialTheme.typography.displayLarge, fontWeight = FontWeight.Bold)
            Button(
                onClick = { score++; vm.review(k.id, 2); index++ },
                modifier = Modifier.fillMaxWidth()
            ) { Text(k.meaning) }
            OutlinedButton(
                onClick = { vm.review(k.id, 0); index++ },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Review again") }
            Text("Score: $score")
        }
        OutlinedButton(onClick = back, modifier = Modifier.fillMaxWidth()) { Text("Exit") }
    }
}

