# TYRO KANJI

Offline Japanese Kanji learning app built with Kotlin, Jetpack Compose, Material 3, Room, WorkManager, Navigation Compose and Jetpack Glance.

## Build
Use JDK 17 and Gradle 8.11.1. Run `gradle assembleDebug` or use the included GitHub Actions workflow.

## Widget
Resizable, theme-adaptive widget with a top-right refresh action. It intentionally does not display JLPT. Quiz and SRS controls are app-only.

## Data note
The supplied Kanji source available for this build contains 307 records. No unverified Kanji were invented to reach 320. Replace/extend `KanjiCatalog` with the user's authoritative remaining 13 records when available.
