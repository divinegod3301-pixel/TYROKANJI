# Data status

The supplied source file used for this project contains 307 Kanji records. The app is designed for the requested 320-record catalog, but the missing 13 records are intentionally not fabricated.

JLPT labels in this prototype are data fields and should be replaced by the user's authoritative N4/N5 mapping when supplied.
