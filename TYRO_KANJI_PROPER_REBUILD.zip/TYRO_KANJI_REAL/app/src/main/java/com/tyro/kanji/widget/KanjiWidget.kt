package com.tyro.kanji.widget

import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.*
import androidx.glance.action.ActionCallback
import androidx.glance.action.ActionParameters
import androidx.glance.action.actionRunCallback
import androidx.glance.appwidget.*
import androidx.glance.layout.*
import androidx.glance.text.*
import androidx.glance.appwidget.cornerRadius
import kotlin.random.Random

object WidgetState { var index:Int=0 }
class RefreshCallback:ActionCallback{ override suspend fun onAction(context:android.content.Context,parameters:ActionParameters){WidgetState.index=Random.nextInt(0,KanjiWidgetData.items.size); KanjiWidget().updateAll(context)} }
class KanjiWidget:GlanceAppWidget(){ override suspend fun provideGlance(context:android.content.Context,id:GlanceId){provideContent{WidgetUi()}} }
@Composable fun WidgetUi(){
 val k=KanjiWidgetData.items[WidgetState.index%KanjiWidgetData.items.size]
 Box(GlanceModifier.fillMaxSize().cornerRadius(24.dp).background(GlanceTheme.colors.widgetBackground).padding(14.dp)){
  Column(GlanceModifier.fillMaxSize(),verticalAlignment=Alignment.CenterVertically,horizontalAlignment=Alignment.CenterHorizontally){
   Row(GlanceModifier.fillMaxWidth(),horizontalAlignment=Alignment.End){Text("↻",GlanceModifier.clickable(actionRunCallback<RefreshCallback>()),style=TextStyle(fontSize=18.sp,color=GlanceTheme.colors.onSurface))}
   Spacer(GlanceModifier.height(2.dp)); Text(k.kanji,style=TextStyle(fontSize=38.sp,fontWeight=FontWeight.Bold,color=GlanceTheme.colors.onSurface)); Text(k.hiragana,style=TextStyle(fontSize=17.sp,color=GlanceTheme.colors.onSurface)); Text(k.romaji,style=TextStyle(fontSize=13.sp,color=GlanceTheme.colors.onSurface)); Text(k.meaning,style=TextStyle(fontSize=14.sp,color=GlanceTheme.colors.onSurface),maxLines=2)
  }
 }
}
object KanjiWidgetData{data class W(val kanji:String,val hiragana:String,val romaji:String,val meaning:String);val items=listOf(W("人","ひと","hito","person"),W("日","ひ","hi","day / sun"),W("一","いち","ichi","one"),W("二","に","ni","two"),W("三","さん","san","three"),W("顔","かお","kao","face"),W("声","こえ","koe","voice"),W("森","もり","mori","forest"))}
class KanjiWidgetReceiver:GlanceAppWidgetReceiver(){override val glanceAppWidget=KanjiWidget()}
