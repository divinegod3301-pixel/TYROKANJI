package com.tyro.kanji.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName="kanji")
data class KanjiEntity(@PrimaryKey val id:Int,val kanji:String,val hiragana:String,val romaji:String,val meaning:String,val jlpt:String,val example:String="",val exampleTranslation:String="",val strokeCount:Int=0,val onyomi:String="",val kunyomi:String="")
@Entity(tableName="progress", primaryKeys=["kanjiId"])
data class ProgressEntity(val kanjiId:Int,val ease:Float=2.5f,val interval:Int=0,val repetitions:Int=0,val dueAt:Long=0,val mastered:Boolean=false,val correct:Int=0,val wrong:Int=0,val favorite:Boolean=false)
@Dao interface KanjiDao {
 @Query("SELECT * FROM kanji ORDER BY id") fun all():Flow<List<KanjiEntity>>
 @Query("SELECT * FROM kanji WHERE kanji LIKE '%' || :q || '%' OR meaning LIKE '%' || :q || '%' OR hiragana LIKE '%' || :q || '%' OR romaji LIKE '%' || :q || '%' ORDER BY id") fun search(q:String):Flow<List<KanjiEntity>>
 @Query("SELECT * FROM kanji WHERE id=:id") suspend fun get(id:Int):KanjiEntity?
 @Query("SELECT COUNT(*) FROM progress WHERE mastered=1") fun masteredCount():Flow<Int>
 @Query("SELECT COUNT(*) FROM progress WHERE dueAt <= :now") fun dueCount(now:Long):Flow<Int>
 @Query("SELECT * FROM progress WHERE kanjiId=:id") suspend fun progress(id:Int):ProgressEntity?
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun insertKanji(items:List<KanjiEntity>)
 @Insert(onConflict=OnConflictStrategy.REPLACE) suspend fun saveProgress(p:ProgressEntity)
 @Query("UPDATE progress SET favorite=:fav WHERE kanjiId=:id") suspend fun favorite(id:Int,fav:Boolean)
}
@Database(entities=[KanjiEntity::class,ProgressEntity::class],version=1,exportSchema=false)
abstract class TyroDatabase:RoomDatabase(){ abstract fun kanjiDao():KanjiDao
 companion object { @Volatile private var I:TyroDatabase?=null; fun get(c:Context)=I?:synchronized(this){I?:Room.databaseBuilder(c.applicationContext,TyroDatabase::class.java,"tyro_kanji.db").build().also{I=it}} }
}
class KanjiRepository(private val dao:KanjiDao){
 val all=dao.all(); fun search(q:String)=dao.search(q); val mastered=dao.masteredCount(); fun due()=dao.dueCount(System.currentTimeMillis())
 suspend fun get(id:Int)=dao.get(id)
 suspend fun seed(){ if(dao.get(1)==null) dao.insertKanji(KanjiCatalog.items.map{KanjiEntity(it.id,it.kanji,it.hiragana,it.romaji,it.meaning,it.jlpt)}) }
 suspend fun review(id:Int,rating:Int){ val old=dao.progress(id)?:ProgressEntity(id); val next=when(rating){0->1;1->maxOf(1,(old.interval*1.5).toInt());2->maxOf(2,old.interval*2);else->maxOf(4,(old.interval*3).toInt())}; dao.saveProgress(old.copy(interval=next,repetitions=old.repetitions+1,dueAt=System.currentTimeMillis()+next*86400000L,mastered=next>=30,correct=old.correct+if(rating>0)1 else 0,wrong=old.wrong+if(rating==0)1 else 0)) }
 suspend fun toggleFavorite(id:Int){ val p=dao.progress(id)?:ProgressEntity(id); dao.saveProgress(p.copy(favorite=!p.favorite)) }
}
