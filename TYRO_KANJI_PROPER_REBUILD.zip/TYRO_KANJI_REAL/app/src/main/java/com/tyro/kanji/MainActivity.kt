package com.tyro.kanji
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.*
import com.tyro.kanji.data.KanjiEntity

@OptIn(ExperimentalMaterial3Api::class)
class MainActivity:ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);setContent{TyroApp()}}}
@Composable fun TyroApp(vm:MainViewModel=viewModel()){
 val nav=rememberNavController(); MaterialTheme(colorScheme=if(isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()){
 NavHost(nav,"home"){
  composable("home"){Home(vm,{nav.navigate("learn")},{nav.navigate("quiz")})}
  composable("learn"){Learn(vm){nav.navigate("detail/$it")}}
  composable("detail/{id}"){val id=it.arguments?.getString("id")!!.toInt(); val item=vm.kanji.collectAsState(emptyList()).value.firstOrNull{it.id==id}; item?.let{Detail(it,vm,{nav.popBackStack()})}}
  composable("quiz"){Quiz(vm){nav.popBackStack()}}
 }
 }
}
@Composable fun Shell(title:String,content:@Composable ColumnScope.()->Unit){Scaffold(topBar={TopAppBar(title={Text(title,fontWeight=FontWeight.Bold)})}){p->Column(Modifier.padding(p).padding(16.dp).fillMaxSize(),verticalArrangement=Arrangement.spacedBy(14.dp),content=content)}}
@Composable fun Home(vm:MainViewModel,learn:()->Unit,quiz:()->Unit){val mastered by vm.mastered.collectAsState(0);val due by vm.due.collectAsState(0);Shell("TYRO KANJI"){Text("Your daily Japanese practice",style=MaterialTheme.typography.titleMedium);Card(shape=RoundedCornerShape(24.dp)){Column(Modifier.padding(20.dp)){Text("Today's Kanji",style=MaterialTheme.typography.labelLarge);Text("一",style=MaterialTheme.typography.displayMedium,fontWeight=FontWeight.Bold);Text("いち • ichi • one")}}Row(horizontalArrangement=Arrangement.spacedBy(12.dp)){Stat("Mastered",mastered.toString(),Modifier.weight(1f));Stat("Reviews",due.toString(),Modifier.weight(1f))};Button(learn,Modifier.fillMaxWidth()){Text("Learn Kanji")};OutlinedButton(quiz,Modifier.fillMaxWidth()){Text("Start Quiz")};Text("Progress",style=MaterialTheme.typography.titleLarge);LinearProgressIndicator({(mastered/307f).coerceIn(0f,1f)},Modifier.fillMaxWidth());Text("$mastered / 307 learned")}}
@Composable fun Stat(a:String,b:String,m:Modifier){Card(m){Column(Modifier.padding(16.dp)){Text(a);Text(b,style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)}}}
@Composable fun Learn(vm:MainViewModel,open:(Int)->Unit){val items by vm.results.collectAsState();Shell("Kanji Library"){OutlinedTextField(vm.query.collectAsState().value,vm::setQuery,label={Text("Search kanji, meaning, hiragana or romaji")},modifier=Modifier.fillMaxWidth());LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){items(items){k->Card(Modifier.fillMaxWidth().clickable{open(k.id)},RoundedCornerShape(18.dp)){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Text(k.kanji,style=MaterialTheme.typography.displaySmall,Modifier.width(70.dp));Column{Text(k.meaning,fontWeight=FontWeight.Bold);Text("${k.hiragana} • ${k.romaji}");Text(k.jlpt,style=MaterialTheme.typography.labelSmall)}}}}}}}
@Composable fun Detail(k:KanjiEntity,vm:MainViewModel,back:()->Unit){Shell("Kanji Details"){Text(k.kanji,style=MaterialTheme.typography.displayLarge,fontWeight=FontWeight.Bold);Text(k.hiragana,style=MaterialTheme.typography.headlineMedium);Text(k.romaji,style=MaterialTheme.typography.titleLarge);Text(k.meaning,style=MaterialTheme.typography.headlineSmall);AssistChip({},{Text(k.jlpt)});Spacer(Modifier.height(8.dp));Text("Example sentence");Text(if(k.example.isBlank()) "Example coming from your complete dataset" else k.example);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button({vm.review(k.id,0)}){Text("Again")};Button({vm.review(k.id,2)}){Text("Good")};Button({vm.favorite(k.id)}){Text("Favorite")}};OutlinedButton(back,Modifier.fillMaxWidth()){Text("Back")}}}
@Composable fun Quiz(vm:MainViewModel,back:()->Unit){var idx by remember{mutableIntStateOf(0)};var score by remember{mutableIntStateOf(0)};val list by vm.kanji.collectAsState(emptyList());val k=list.getOrNull(idx%maxOf(1,list.size));Shell("Quiz"){if(k!=null){Text("What does this mean?",style=MaterialTheme.typography.titleLarge);Text(k.kanji,style=MaterialTheme.typography.displayLarge,fontWeight=FontWeight.Bold);Button({score++;vm.review(k.id,2);idx++},Modifier.fillMaxWidth()){Text(k.meaning)};OutlinedButton({vm.review(k.id,0);idx++},Modifier.fillMaxWidth()){Text("Review again")};Text("Score: $score")};OutlinedButton(back,Modifier.fillMaxWidth()){Text("Exit")}}}
