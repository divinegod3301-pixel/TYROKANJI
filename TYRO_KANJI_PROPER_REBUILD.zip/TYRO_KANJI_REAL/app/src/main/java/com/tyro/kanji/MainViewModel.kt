package com.tyro.kanji
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tyro.kanji.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
class MainViewModel(app:Application):AndroidViewModel(app){
 private val repo=KanjiRepository(TyroDatabase.get(app))
 val kanji=repo.all; val mastered=repo.mastered; val due=repo.due()
 val query=MutableStateFlow(""); val results=query.flatMapLatest{if(it.isBlank()) repo.all else repo.search(it)}.stateIn(viewModelScope,SharingStarted.WhileSubscribed(5000),emptyList())
 init{viewModelScope.launch{repo.seed()}}
 fun setQuery(q:String){query.value=q}; fun review(id:Int,r:Int)=viewModelScope.launch{repo.review(id,r)}; fun favorite(id:Int)=viewModelScope.launch{repo.toggleFavorite(id)}
}
